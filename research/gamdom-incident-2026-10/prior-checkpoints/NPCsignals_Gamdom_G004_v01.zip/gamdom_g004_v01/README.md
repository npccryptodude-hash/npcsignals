# NPCsignals — Gamdom G004 Transaction Reconstruction v0.1
Date: 2026-10-15
Status: BLOCKED — no incident-linked transaction hashes verified. Publication: HOLD.

## Evidence discipline
No attack address, chain hop, cross-chain bridge deposit, or amount is marked CONFIRMED without a transaction receipt and defensible incident attribution.

## Findings
- SlowMist catalogues the event as an October 13, 2026 hot-wallet-server compromise with an estimated USD 4,208,000 loss (SUPPORTED third-party report).
- vxdb's reported loss estimate is approximately $2.2m EVM, $965k Solana, $375k TRON, and $668k Bitcoin. These rounded numbers sum to $4.208m but are not transaction reconciliation.
- ChainCatcher/KuCoin reports alleged movement via cross-chain bridges, Hyperliquid and THORChain (REPORTED only).
- Arkham's pre-existing Gamdom hot-wallet label 0xB70F98e53BEE56A2E18A15bcd826579f495076F0 is a third-party attribution, not an incident-linked outgoing transaction.
- PolygonScan labels 0xd5FBDa4C79F38920159fE5f22DF9655FDe292d47 'Gamdom: Hot Wallet'; not incident-linked, do not attribute attack to this wallet.
- DappRadar publicly claims 127 tracked Gamdom wallets but its labels/coverage require validation and do not establish breach role.

## Blocking evidence
No verified attack transaction signature/hash, reliable list of incident-controlled victims, attacker address, or bridge receipt was available in the sources reviewed. Thus: verified incident transfers=0; confirmed stolen amount by NPCsignals=NOT ASSESSED; owner/operator attribution=UNRESOLVED.

## Next technical steps
1. Locate vxdb's original post/thread with complete wallet IDs and chain receipts; preserve URL, capture date and publication time.
2. Request Gamdom's published compromised wallet set and transaction references if available.
3. For each candidate: query explorer for October 13–15 outgoing transactions, compare historical behavior, record signer/owner, token mint, block/slot, timestamp UTC, amount, fees, chain, receipt URL and source.
4. Match cross-chain hops only with bridge-specific transaction/order identifiers; avoid service-deposit-as-control inference.
5. Compute net loss from first unauthorized outflows rather than sum every downstream hop; price at consistent time, segregate protective transfers.

## Primary and secondary sources
https://hacked.slowmist.io/
https://www.tokenpost.com/news/technology/32166
https://www.kucoin.com/news/flash/gamdom-suspected-of-being-hacked-losing-approximately-4-2-million
https://polygonscan.com/address/0xd5fbda4c79f38920159fe5f22df9655fde292d47
https://dappradar.com/dapp/gamdom
https://arkm.com/explorer/address/0xB70F98e53BEE56A2E18A15bcd826579f495076F0

Preserve the separately generated G001-G003 checkpoint; this package does not supersede or alter its evidence.
