# NPCsignals — Gamdom Incident Reconstruction
Checkpoint: G001–G003 v0.1
Date: 2026-10-15
Status: RESEARCH ACTIVE / PUBLICATION HOLD

## Scope
- G001: preliminary incident chronology
- G002: candidate wallet attribution
- G003: reconcile reported cross-chain losses

## Evidence grading
- CONFIRMED (source content): user-supplied screenshot displays Gamdom's statement, dated 2026-10-14 05:36 in Norwegian UI time. The source claims a potential disk failure and unauthorized automation-server connection, precautionary shutdown and customer funds safe. Screenshot authenticity and original X metadata have NOT been independently validated.
- SUPPORTED (secondary): SlowMist incident register lists Gamdom on 2026-10-13 as a hot-wallet server compromise, USD 4,208,000.
- REPORTED: vxdb estimate reproduced by TokenPost totals USD 4,208,000 over EVM, Solana, BTC and TRON.
- REPORTED: founder Felix Roemer statement about losses slightly above USD 3m, relayed by Gate reporting; direct original post still needed.
- THIRD-PARTY LABEL: Arkham labels Ethereum address 0xB70F98e53BEE56A2E18A15bcd826579f495076F0 a Gamdom hot wallet. No event-specific attack transfer has been verified for this address.
- UNRESOLVED: first unauthorized tx; compromised wallet set; bridge routes; customer deposit liability; provenance of the $3m vs $4.208m difference.

## Non-findings
No verified exploit transactions, no attacker attribution, no verified recovery or customer loss, and no verified reconciliation. Do not allege criminal identity or financial misconduct.

## Next evidence gate
Obtain original Gamdom/Felix/vxdb post URLs and time-stamped wallet/transaction hashes for each network. Independently verify tx receipts and cluster attribution. Reconstruct gross outflows vs unauthorized net loss, avoiding internal transfers and double-counting bridges.

## Sources
See sources.csv. Figures are reported estimates, not independently verified transfers.
