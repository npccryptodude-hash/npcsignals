# NPCsignals — Binance Evidence Package v2.0

Research date: 2026-10-14. Prepared from user-provided ChatGPT Work completed checkpoints. This is a consolidated **secondary index**, not the seven original receipts or both source evidence archives. Exported original JSON-RPC responses, finality checks, hashes, CSV/JSON and replay scripts must be preserved separately.

## Finding and limitations
Two documented case-connected sending routes lead to the same Binance-attributed Solana infrastructure address: `5tzFkiKscXHK5ZXCGbXZxdw7gTjjD1mBwuoFbhUvuAi9`.

- **CONFIRMED per Work's re-fetched finalized receipts:** the five on-chain transfers, senders/authorities and relevant historical token owner.
- **SUPPORTED:** recipient is Binance-related infrastructure according to Bitquery's exact-address label and Solscan's `Binance 2` label. An official Binance historical address-ownership attestation was not recovered.
- **UNRESOLVED:** customer deposit credit vs internal custodial movement, whether Binance also controlled any source, account owner/beneficiary, common individual operator, and source of money.

## Route A: ZYROX U300 (native SOL)
Sender: `8zHcWujHhyJri3CRTcWUGmT5WSRdwW7xrns3WTTkPGvS` (exact match ZYROX primary-ledger U300). Receiver: `5tzFkiKscXHK5ZXCGbXZxdw7gTjjD1mBwuoFbhUvuAi9`. All System Program transfers, zero-based `outer:2`, sender sole signer/authority/fee payer, fee 9,000 lamports each, finalized successful per Work.

| ID | UTC | Slot | SOL | Signature |
|---|---|---:|---:|---|
| SC001 | 2026-09-30 17:03:07 | 452026176 | 52.383204688 | `3tPBHCeM4Y86RETWoAhmFKD1JjVs4GWduMxzsYwSstKktAKg3jovJbr54dUhaHfh1L8vxQJiGJ3BVgYhRs92vgWY` |
| SC002 | 2026-09-30 17:06:00 | 452026821 | 292.066250817 | `4SxWP8XZRb3z1zg5dcTCsvGvMNtBm92zfibZ2KHySAVCZ34nTN9st6MrcaY7NnDfC8dsRsCMyiX6wMf4KoB9YsNm` |
| SC003 | 2026-09-30 17:12:00 | 452028164 | 105.583014451 | `4xyFCL3f67ejRXTf3NZHgXScUVfXdCiWPsx9NNM1UWeNnmvMWcAFzGzYzGYapWFgHyFBD1aNmM9WDte7DbkpYnGe` |
| SC004 | 2026-10-14 06:00:01 | 456730989 | 22.896954041 | `4m6gaPuwQnwN7KFSeCi3SzaqJzyj6JPzL5sMjq2c3gYuniYAqg3kZMPsseDdomzVJaVjZF3LPXYyHXAqeKKfSuYb` |

September 30 subtotal: **450.032469956 SOL**. Route A total: **472.929423997 SOL**. The three September 30 transfers occurred *before* the recorded 17:18 UTC ZYROX creator purchase and **cannot be represented as proceeds from that purchase**. The later U300 wallet also received a GLITCH-related routing transaction; address-level links do not show common human ownership.

## Route B: 6hR7 → 56HEQ → Binance-attributed USDT token account
Case-linked sender: `6hR7GwHpdHbJgNJAagm64KMsMYu8mR6ExzmbE5N8wv1N`. Historical receiver owner and subsequent USDT transfer authority: `56HEQykziUkwvpK5uPzFrRbGD4Ek8HdWgjgeDvNmDoEJ`. USDT source token account: `CzissnPHhEu7NifSLfwhuvFMdfu7F8X4vR2HhF1o1PEL`.

6hR7 paid 4.028124 USDT at 2026-09-24 11:49:54 UTC slot 450020165 and 991.803278 USDT at 11:57:57 UTC slot 450021997, totaling **995.831402 USDT**. Starting complete signatures are in the original Work package; they were not supplied in this chat excerpt.

At **2026-09-24 12:03:01 UTC**, slot **450023141**, 56HEQ transferred **995.831502 USDT** from `Czissn...` to receiving token account `CyBjGpte4Npi5zNkdtWumPxVW4kpMR8BuFSbA587xZES`, historical owner `5tzFkiKscXHK5ZXCGbXZxdw7gTjjD1mBwuoFbhUvuAi9`. Instruction SPL `transferChecked`, zero-based `outer:2`.

Full signature: `3QrJH49NS39jAtvEPn8BxCNGqkiwMZk1kSDJ2GU8f8jVU5GxVzxzd9bKSLx2KYkm7G6mPLP8Vsk3S94TuZMiayz2`.

Source owner/authority: 56HEQ. **Separate fee payer and additional signer**: `5JPAWfhLNsYVk3tPpD3gHvpHbvaXDbpUpy1wUfQVYRS2`. Transaction fee: **14,000 lamports**. Successful finalized per Work. The additional 0.000100 USDT came from a separate inflow; do not attribute 995.831502 wholly to 6hR7. This transaction drained then-current source balance to zero; 0.001000 USDT arrived later.

## What authorized investigators can ask Binance
For all five signatures and historical timestamps: (a) verify whether Binance controlled the receiver and receiving USDT token account; (b) classify each booking as client/customer deposit, internal treasury sweep, or another operation; (c) ascertain relevant internal transaction IDs, booking records and source-address attribution; (d) establish whether sending addresses could have belonged to Binance itself or another custodian; (e) preserve and disclose relevant records through appropriate lawful request processes.

Official law-enforcement guideline: https://www.binance.com/en/support/law-enforcement/guidelines

No provider contacted. No named individual identified. No allegation of criminal conduct proved.

## Remaining evidence preservation
Store unmodified original Work evidence exports for both source routes and their SHA-256 manifests. Re-run the offline verifiers, record RPC service/provider provenance and capture timestamp, and reconcile each transaction before transmitting any evidence packet.
