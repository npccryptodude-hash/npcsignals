# NPCsignals – Evidence archive status, 2026-10-14

## Present in this bundle
- NPCsignals_Binance_Evidence_Package_v2.0.md: consolidated secondary evidence index with five completed transfer references, source-wallet routes, limits and lawful referral questions.
- This archive status and SHA-256 manifest.

## Verified in GitHub
- research/EXCHANGE_ATTRIBUTION_LEDGER_v0.1.md
- research/EXCHANGE_ATTRIBUTION_LEDGER_v0.2.md
- research/BINANCE_U300_EVIDENCE_PACKAGE_v1.0_CHECKPOINT.md
- research/BINANCE_U300_INDEPENDENT_LABEL_CORROBORATION_2026-10-14.md
- research/EXCHANGE_ATTRIBUTION_ARCHIVE_STATUS_2026-10-14.md (commit 6348371f21b8dbb6693297ef775092db9fed6ff1)

## Still missing
- Original Work export archives (JSON-RPC responses, finalized status, complete CSV/JSON ledgers, hashes and offline replay scripts) for U300 SOL and 56HEQ USDT routes.
- Complete initiating signatures for two 6hR7 to 56HEQ payments (only slots and amounts provided in chat).
- Binance-controlled-address confirmation from Binance itself and internal transaction classification.

## Evidence constraints
These documents are *not* the original receipts. Five finalized transfers were reported as independently reproduced by Work. Binance address attribution remains supported by public analytical labels, not a Binance primary-source address declaration. Customer deposits, account holders, and beneficial ownership are unresolved. Do not assert specific tokensale provenance; Sep 30 native SOL payments precede recorded ZYROX creator purchase.

## Required next preservation action
Upload the complete unmodified Work evidence exports and their original manifests; compare checksums, run offline checkers, and save a dated chain-of-custody log. No exchange contact made.
