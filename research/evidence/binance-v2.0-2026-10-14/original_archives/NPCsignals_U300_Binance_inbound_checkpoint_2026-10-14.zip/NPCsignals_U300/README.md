# NPCsignals U300 exchange-inbound checkpoint — 2026-10-14

## Outcome

CONFIRMED: U300 wallet 8zHcWujHhyJri3CRTcWUGmT5WSRdwW7xrns3WTTkPGvS transferred 22.896954041 native SOL to 5tzFkiKscXHK5ZXCGbXZxdw7gTjjD1mBwuoFbhUvuAi9 on 2026-10-14 at 06:00:01 UTC, slot 456730989, transaction index 351. The receipt is successful and its separately retrieved status is finalized.

Signature: 4m6gaPuwQnwN7KFSeCi3SzaqJzyj6JPzL5sMjq2c3gYuniYAqg3kZMPsseDdomzVJaVjZF3LPXYyHXAqeKKfSuYb

Instruction outer:2 (zero-based): System Program transfer of 22,896,954,041 lamports. Sole signer, native transfer authority and fee payer: 8zHc. Fee: 9,000 lamports. No SPL token account, token mint, closure, wrapping, swap or bridge appears in this transaction. Compute-budget instructions are preserved as opaque instructions at outer:0 and outer:1.

| Account | Before SOL | After SOL | Change SOL |
|---|---:|---:|---:|
| 8zHc | 25.216560668 | 2.319597627 | -22.896963041 |
| Receiver | 1,712,155.917758799 | 1,712,178.814712840 | +22.896954041 |

Source decrease equals transfer plus fee. Recipient increase equals transfer. Historical SPL owners are not applicable to native SOL; parsed account-key roles are preserved.

## Exchange attribution

SUPPORTED by strong independent public evidence: Bitquery explicitly identifies this exact, case-sensitive recipient as a Binance hot wallet in its own research publication. Solscan's retrieved exact-address page title independently labels it Binance 2. Sources and targeted captured excerpts are in sources.json. Bitquery states the key appears in Binance's proof of reserves; that exact binding was not independently recovered from Binance's own dynamic reserves page. Do not elevate this to independently captured official publication evidence.

This establishes an actionable inbound transfer to independently Binance-attributed infrastructure. UNRESOLVED: whether it was booked as a customer deposit or an internal custodial sweep, whether 8zHc is itself a custodial address, and which account/customer, if any, was credited. These distinctions require Binance records. No customer identity, common control, human controller or sale-exclusive provenance is established.

## Independent network connection

The existing ZYROX primary ledger was read before querying this wallet. U300 records a transfer from H85KW8sDNzbs2ykUuapYcdNhbwoNQfBn3zFZTvBdx7kG to this exact 8zHc address. Its finalized receipt and status were independently fetched again:

- Signature T7To7CBLjCmV16JL3vTyuTvgze5kuuRvXjdoP6AgmQiRu8urjsPGpJm3nsxypA9cipPD8UjmyMqeDBEvjAK55zk.
- 139.458181476 SOL; 2026-10-02 11:42:19 UTC; slot 452599835; transaction index 532; outer:0.
- H85 is the sole signer, authority and fee payer; 5,000 lamport fee; H85 balance 139.458186476 SOL to zero. 8zHc balance 0.009996000 to 139.468177476 SOL.
- Primary document: https://github.com/npccryptodude-hash/npcsignals/blob/main/research/zyrox-investigation/evidence/ZYROX_Devsold_verification_v0_2.md ; local Git blob hash 08cf6b40c8aac00fb5d378ad1bc9b655bce62e55.

The supplied October 13 incoming receipt is also preserved and its finality rechecked: 4tKWJNnFjwr7J7JsVY8dMAAS1u2KfYpvQDHf9aHcbHpeP7pMCBMZ5xeQPRMFhgxMsnbdFMiKQfseKxz796t195zh; 128.120282252 SOL; 23:08:24 UTC; slot 456617643. It does not establish that the later exchange-bound amount exclusively came from that receipt. Balances are commingled.

## Exact tested scope and negative findings

93 pages / 93,000 finalized signature references are preserved, spanning the indexed head at 2026-10-14 05:54:44 UTC back to 2026-09-28 15:48:24 UTC. Pagination stopped without an empty terminal page after the actionable transfer was found. This is NOT a complete lifetime history or exhaustive outgoing-token audit. The 06:00:01 transfer was discovered in a later enhanced RPC response, after the earlier pagination head, and independently re-fetched using getTransaction. scope.json preserves the resume cursor.

- The prior 22-exchange address registry did not yield an exact matching receiver. It is not exhaustive.
- A case-variant PDF address was rejected; Solana address matches are case-sensitive.
- Official Binance proof-of-reserves dynamic page did not expose this exact address in captured text. No inference from its generic reserves wording.
- Solscan corroboration is its returned page title; the dynamic body did not render the label.
- Enhanced RPC outgoing-direction filter returned an incoming native SOL transfer too; it cannot be treated as an exhaustive native-outgoing filter. Original response preserved.
- NOT ASSESSED: full older history, exhaustive SPL/swaps/bridges, upstream/downstream expansion and private account attribution. No negative claim that these do not exist.

## Provider-ready inquiry lead

An authorized request to Binance can supply CEX001's signature, network, slot, UTC, addresses and exact lamports, and ask whether Binance controlled the destination at that time; how this receipt was booked; whether 8zHc was a deposit/sweep address; and the associated internal transaction/account records if legally disclosable. Official channel: https://www.binance.com/en/support/law-enforcement . No request has been sent.

## Replay and preservation

Run `python3 verify.py` from this extracted directory (standard library only). It checks file hashes, parsed instructions, exact deltas, fees and successful finalized status records. The full RPC result objects retain every receipt field; transport JSON-RPC envelopes were not retained. Finality status objects are preserved separately. Hash checks detect later file changes; they do not authenticate a provider response or prove exchange ownership. Source attribution must be reviewed separately using sources.json.

instruction-ledger.csv contains all outer instructions and fees of the three key receipts, with stable NET001/NET002/CEX001 IDs. All raw amounts are integer lamports; decimal SOL fields are exact nine-place representations. The source history JSON includes both individual pages and a combined index. Supporting discovery responses are preserved without asserting exhaustive decoding. GitHub was not modified.
