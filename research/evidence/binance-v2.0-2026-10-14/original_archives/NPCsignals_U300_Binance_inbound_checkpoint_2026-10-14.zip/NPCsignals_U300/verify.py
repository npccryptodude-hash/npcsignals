"""Offline receipt/ledger consistency checks. Does not authenticate RPC responses cryptographically.
Run: python3 verify.py (Python standard library only).
"""
import pathlib,json,csv,hashlib,datetime
P=pathlib.Path(__file__).resolve().parent
manifest=json.loads((P/'sha256-manifest.json').read_text())
for name,digest in manifest.items():assert hashlib.sha256((P/name).read_bytes()).hexdigest()==digest,name
rows=list(csv.DictReader((P/'instruction-ledger.csv').open(newline='')))
for r in rows:
 t=json.loads((P/(r['signature']+'.json')).read_text());m=t['meta'];ks=t['transaction']['message']['accountKeys'];keys=[k['pubkey'] for k in ks]
 assert t['meta']['err'] is None and str(t['slot'])==r['slot']
 assert datetime.datetime.fromtimestamp(t['blockTime'],datetime.timezone.utc).isoformat()==r['utc']
 assert r['signers']==';'.join(k['pubkey'] for k in ks if k['signer']) and r['fee_payer']==keys[0]
 if r['kind']=='transaction_fee':assert int(r['lamports'])==m['fee'];continue
 i=int(r['instruction_index'].split(':')[1]);ix=t['transaction']['message']['instructions'][i]
 if r['kind']=='opaque':assert 'parsed' not in ix;continue
 v=ix['parsed']['info'];assert r['sender']==v['source'] and r['recipient']==v['destination'] and int(r['lamports'])==v['lamports']
 a=keys.index(v['source']);b=keys.index(v['destination']);n=v['lamports']
 assert int(r['sender_pre_lamports'])==m['preBalances'][a] and int(r['sender_post_lamports'])==m['postBalances'][a]
 assert int(r['recipient_pre_lamports'])==m['preBalances'][b] and int(r['recipient_post_lamports'])==m['postBalances'][b]
 assert m['preBalances'][a]-m['postBalances'][a]==n+(m['fee'] if a==0 else 0)
 assert m['postBalances'][b]-m['preBalances'][b]==n
for name in ['U300-finality.json','starting-inbound-finality.json','candidate-deposit-finality.json']:
 v=json.loads((P/name).read_text())['value'][0];assert v['confirmationStatus']=='finalized' and v['err'] is None
dep=next(r for r in rows if r['id']=='CEX001.I2');assert dep['lamports']=='22896954041' and dep['recipient']=='5tzFkiKscXHK5ZXCGbXZxdw7gTjjD1mBwuoFbhUvuAi9'
print('PASS: file hashes, three successful finalized receipt/status pairs, instruction ledger, exact SOL deltas and fees. Public attribution/customer-credit classification requires separate source review.')
