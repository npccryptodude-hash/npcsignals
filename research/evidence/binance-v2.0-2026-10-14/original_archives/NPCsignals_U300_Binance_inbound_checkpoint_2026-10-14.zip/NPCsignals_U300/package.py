import json,csv,hashlib,datetime,pathlib,shutil,zipfile
P=pathlib.Path(__file__).resolve().parent
specs=[('NET001','T7To7CBLjCmV16JL3vTyuTvgze5kuuRvXjdoP6AgmQiRu8urjsPGpJm3nsxypA9cipPD8UjmyMqeDBEvjAK55zk','U300-finality.json'),('NET002','4tKWJNnFjwr7J7JsVY8dMAAS1u2KfYpvQDHf9aHcbHpeP7pMCBMZ5xeQPRMFhgxMsnbdFMiKQfseKxz796t195zh','starting-inbound-finality.json'),('CEX001','4m6gaPuwQnwN7KFSeCi3SzaqJzyj6JPzL5sMjq2c3gYuniYAqg3kZMPsseDdomzVJaVjZF3LPXYyHXAqeKKfSuYb','candidate-deposit-finality.json')]
headers=['id','signature','utc','slot','transaction_index','instruction_index','kind','sender','recipient','lamports','sol','signers','fee_payer','sender_pre_lamports','sender_post_lamports','recipient_pre_lamports','recipient_post_lamports','historical_spl_owner','result','confirmation','source_url']
rows=[];records=[]
for eid,sig,statusfile in specs:
 t=json.loads((P/(sig+'.json')).read_text());st=json.loads((P/statusfile).read_text())['value'][0]
 assert st['confirmationStatus']=='finalized' and st['err'] is None and st['slot']==t['slot'] and t['meta']['err'] is None
 keys=t['transaction']['message']['accountKeys'];addresses=[k['pubkey'] for k in keys];signers=';'.join(k['pubkey'] for k in keys if k['signer']);payer=addresses[0];utc=datetime.datetime.fromtimestamp(t['blockTime'],datetime.timezone.utc).isoformat();m=t['meta']
 for i,ix in enumerate(t['transaction']['message']['instructions']):
  p=ix.get('parsed',{});info=p.get('info',{});kind=p.get('type','opaque');s=info.get('source','');d=info.get('destination','');n=info.get('lamports');a=addresses.index(s) if s in addresses else None;b=addresses.index(d) if d in addresses else None
  vals=[eid+'.I'+str(i),sig,utc,t['slot'],t.get('transactionIndex',''),'outer:'+str(i),kind,s,d,'' if n is None else n,'' if n is None else f'{n/1e9:.9f}',signers,payer,'' if a is None else m['preBalances'][a],'' if a is None else m['postBalances'][a],'' if b is None else m['preBalances'][b],'' if b is None else m['postBalances'][b],'N/A native SOL','SUCCESS','finalized','https://solscan.io/tx/'+sig]
  rows.append([str(v) for v in vals])
  if n is not None:records.append(dict(zip(headers,rows[-1])))
 rows.append([str(v) for v in [eid+'.FEE',sig,utc,t['slot'],t.get('transactionIndex',''),'fee','transaction_fee',payer,'',m['fee'],f"{m['fee']/1e9:.9f}",signers,payer,m['preBalances'][0],m['postBalances'][0],'','','N/A native SOL','SUCCESS','finalized','https://solscan.io/tx/'+sig]])
(P/'csv-rows.json').write_text(json.dumps([headers]+rows))
(P/'transfer-records.json').write_text(json.dumps(records,indent=2))
h=json.loads((P/'8zHcWujHhyJri3CRTcWUGmT5WSRdwW7xrns3WTTkPGvS-history.json').read_text());hist={'indexed_references':len(h['rows']),'pages':len(h['pages']),'terminal_empty_page':not h['pages'][-1]['rows'],'head_utc':datetime.datetime.fromtimestamp(h['rows'][0]['blockTime'],datetime.timezone.utc).isoformat(),'oldest_utc':datetime.datetime.fromtimestamp(h['rows'][-1]['blockTime'],datetime.timezone.utc).isoformat(),'resume_before':h['rows'][-1]['signature'],'lifetime_complete':False}
(P/'scope.json').write_text(json.dumps(hist,indent=2))
