import json,pathlib,urllib.request,time,datetime,concurrent.futures,sys,os
P=pathlib.Path(__file__).resolve().parent
P.mkdir(exist_ok=True)
CACHES=[P.parent/x for x in ['exchange-network-pass','exchange-deposit-pass','attribution-pass','8hc-verification','glitch-b-disposition','glitch-proceeds']]
def save(n,d):(P/n).write_text(json.dumps(d,indent=2)+'\n')
def rpc(method,params):
 for n in range(3):
  try:
   req=urllib.request.Request('https://api.mainnet-beta.solana.com',data=json.dumps({'jsonrpc':'2.0','id':1,'method':method,'params':params}).encode(),headers={'Content-Type':'application/json'})
   with urllib.request.urlopen(req,timeout=25) as f:d=json.load(f)
   if d.get('error'):raise RuntimeError(str(d['error']))
   return d['result']
  except Exception:
   if n==2:raise
   time.sleep(2**n)
def history(w):
 rows=[];pages=[];before=None
 while True:
  opts={'limit':1000,'commitment':'finalized'}
  if before:opts['before']=before
  part=rpc('getSignaturesForAddress',[w,opts]);pages.append({'before':before,'rows':part});rows+=part
  save(w+'-history.json',{'wallet':w,'captured_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'pages':pages,'rows':rows})
  print('HISTORY',w,len(part),len(rows),flush=True)
  if not part:break
  before=part[-1]['signature']
 return rows
def fetch(sig):
 dst=P/(sig+'.json')
 if dst.exists():return {'signature':sig,'provenance':'current pass cached','ok':True}
 for c in CACHES:
  src=c/(sig+'.json')
  if src.exists():dst.write_bytes(src.read_bytes());return {'signature':sig,'provenance':'prior finalized cache','ok':True}
 try:
  d=rpc('getTransaction',[sig,{'encoding':'jsonParsed','commitment':'finalized','maxSupportedTransactionVersion':1}]);save(sig+'.json',d)
  print('FETCH',sig,d['slot'] if d else None,flush=True)
  return {'signature':sig,'provenance':'fresh finalized RPC','ok':d is not None}
 except Exception as e:
  print('ERROR',sig,str(e),flush=True);return {'signature':sig,'ok':False,'error':str(e)}
def collect(w):
 hf=P/(w+'-history.json')
 prior=json.loads(hf.read_text()) if hf.exists() else None
 rows=prior['rows'] if prior and prior.get('pages') and not prior['pages'][-1]['rows'] else history(w)
 sigs=[r['signature'] for r in rows]
 with concurrent.futures.ThreadPoolExecutor(max_workers=int(os.environ.get('NPC_RPC_WORKERS','2'))) as pool:results=list(pool.map(fetch,sigs))
 save(w+'-retrieval.json',results)
 statuses=[]
 for i in range(0,len(sigs),200):statuses+=rpc('getSignatureStatuses',[sigs[i:i+200],{'searchTransactionHistory':True}])['value']
 save(w+'-statuses.json',dict(zip(sigs,statuses)))
 print('DONE',w,len(rows),sum(x['ok'] for x in results),flush=True)
if __name__=='__main__':collect(sys.argv[1])
